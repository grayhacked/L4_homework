from random import randrange
import pickle

# input from users and check if the input is correct
surname = input("Antre epsedow pa mete espas ni let majiskil : ")
while " " in surname or surname.islower() == False:
    surname = input("Dezole ou mete espas oubyen let majiskil, re mete epsedo a: ")

try:
    with open("databases.pkl", "rb") as file:
        scores=pickle.load(file)
except(FileNotFoundError, EOFError):
    scores={}
    
player_score = scores.get(surname, 0)  # get the score of the player if he already played

print("*******************************")
print(f"{surname.upper()} Byenvini nan jwet la wulet la ", end="\n*******************************\n")

# ask the user for the magic number
luck = 5  # luck variable that will be used to count the number of attempts
while True:  # Loop that repeats indefinitely (until the user decides to quit)
    magic_number = randrange(0, 5)
    for i in range(luck):
        while True:
            try:
                user_number = int(input("Antre yon nomb ant 0 ak 5: "))
                if 0 <= user_number <= 5:
                    break
                else:
                    print("Ou dwe antre yon nomb ki ant 0 ak 5.")
            except ValueError:
                print("Ou fe yon sezi invalid. Ou dwe antre yon nomb antye.")
            
        if user_number > magic_number:
            luck -= 1
            print(f"Ou antre yon nomb ki pi gwo ke nomb majik la. ou rete {luck} chans.")
        elif user_number < magic_number:
            luck -= 1
            print(f"Ou antre yon nomb ki pi piti ke nomb majik la. Ou rete {luck} chans.")
        else:
            victory = True
            if victory:
                player_score += luck*30
                print(f"Bravo ou jwenn nomb majik la!! Ou gen {player_score} pwen.")
            break
        if luck == 0:
            print(f"Ou pedi!! Nomb majik la se {magic_number} ")
            break 
    scores[surname] = player_score           
    with open("databases.pkl", "wb") as file:
        pickle.dump(scores, file)        

    # Ask the user if he wants to play again
    reponse = input("Peze \"K\" pou kite jwet la, nenpot buton pou kontinye: ").strip().lower() # remove spaces and put the answer in lowercase
    luck = 5  # reset the luck variable
    if reponse == "k":
        break  # If the answer is "K", exit the loop.
print("Mesi paske ou jwe jwet lawulet la !!!")
