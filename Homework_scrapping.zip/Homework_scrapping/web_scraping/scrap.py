import requests
from bs4 import BeautifulSoup
import csv

url = 'https://lenouvelliste.com/'  
response = requests.get(url)

if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')

    # Scraping titles, links, and images
    titles = [title.text.strip() for title in soup.find_all('h1')]
    articles = soup.find_all('div', class_='lnv-featured-article-lg')

    data = []

    for article in articles:
        links_in_article = [link['href'] for link in article.find_all('a')]
        images_in_article = [image['src'] for image in article.find_all('img')]
        
        # Append data to list
        data.append({
            'Title': titles.pop(0) if titles else '',
            'Links': links_in_article,
            'Images': images_in_article
        })

    # Store data in a CSV file
    with open('scraped_data.csv', 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Title', 'Links', 'Images']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        # Write header
        writer.writeheader()

        # Write data rows
        for row in data:
            writer.writerow(row)

    print("Data successfully stored in scraped_data.csv")

else:
    print("Failed to retrieve the webpage. Status Code:", response.status_code)
